import java.util.Scanner;

public class FifthEx {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        int ev = 0;
        int eq = 0;

        System.out.println("Введите " + n + " чисел:");
        for(int i = 0; i < n; i++){
            String ns = scanner.next();

            if(evORnot(ns)){
                ev++;
            }
            if(eqEvOrN(ns)){
                eq++;
            }
        }
        System.out.println("Чисел с равным кол-вом только чётных: " + ev);
        System.out.println("Чисел с равным кол-вом чётных и нечётных: " + eq);

    }

    private static boolean evORnot(String s){
        for(int i = 0; i < s.length(); i++){
            char ch = s.charAt(i);
            if(Character.isDigit(ch)){
                int d = ch - '0';
                if(d % 2 != 0){return false;}
            }
        }
        return true;
    }

    private static boolean eqEvOrN(String s){
        int even = 0;
        int odd = 0;

        for (int i = 0; i < s.length(); i++){
            char ch = s.charAt(i);
            if (Character.isDigit(ch)){
                int d = ch - '0';
                if (d % 2 == 0){
                    even++;
                }else odd++;
            }
        }
        if (even == odd && even > 0){
            return true;
        }else return false;

    }

}
