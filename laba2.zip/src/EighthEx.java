import java.util.Scanner;

public class EighthEx {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        String sev = null;
        int pal = 0;
        System.out.println("Введите " + n + " чисел:");
        for(int i = 0; i < n; i++){
            String ns = scanner.next();

            if (isPal(ns)) {
                pal++;
                if (pal == 2) {
                    sev = ns;
                }
            }
        }
        if (pal == 0) {
            System.out.println("Палиндромов не найдено.");
        } else if (pal == 1) {
            System.out.println("Второго нет.");
        } else {
            System.out.println(sev);
        }

    }

    private static boolean isPal(String s) {
        int left = 0;
        int right = s.length() - 1;
        while (left < right) {
            if (s.charAt(left) != s.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
}
