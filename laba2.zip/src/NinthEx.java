public class NinthEx {
    public static void main(String[] args) {
        double a = Double.parseDouble(args[0]);
        double b = Double.parseDouble(args[1]);
        double c = Double.parseDouble(args[2]);
        if (a == 0) {
            if (b == 0) {
                if(c == 0){System.out.println("Любое число");}
                else System.out.println("Нет решений");
            } else {
                System.out.println(-c / b);
            }
            return;
        }
        double D = b * b - 4 * a * c;
        if (D >= 0) {
            double x1 = (-b + Math.sqrt(D)) / (2 * a);
            double x2 = (-b - Math.sqrt(D)) / (2 * a);
            if (D == 0) {
                System.out.println(x1);
            } else {
                System.out.println(x1 + " " + x2);
            }
        } else {
            double real = -b / (2 * a);
            double imag = Math.sqrt(-D) / (2 * a);
            System.out.println(real + "+" + imag + "i " + real + "-" + imag + "i");
        }
    }
}
