import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class SecondEx {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        String[] ns = new String[n];
        System.out.println("Введите " + n + " чисел:");
        for(int i = 0; i < n; i++){
            ns[i] = scanner.next();
        }

        for (int i = 0; i < n-1; i++){
            for (int j = 0; j < n - i - 1; j++){
                if(ns[j].length() < ns[j+1].length()){
                    String tmp = ns[j];
                    ns[j] = ns[j+1];
                    ns[j+1] = tmp;
                }
            }
        }

        for (int i = 0; i < n; i++){
            System.out.print(ns[i]+ " ");
        }

    }
}
