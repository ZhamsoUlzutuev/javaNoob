import java.util.Scanner;

public class ThirdEx {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        String[] ns = new String[n];
        int mainL = 0;
        System.out.println("Введите " + n + " чисел:");
        for(int i = 0; i < n; i++){
            ns[i] = scanner.next();
            mainL += ns[i].length();
        }

        double avL = (double) mainL/n;

        for(int i = 0; i < n; i++){
            if(ns[i].length() < avL){
                System.out.println(ns[i]);
            }
        }



    }
}
