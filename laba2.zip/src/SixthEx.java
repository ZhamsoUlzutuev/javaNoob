import java.util.Scanner;

public class SixthEx {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        String first = null;

        System.out.println("Введите " + n + " чисел:");
        for(int i = 0; i < n; i++){
            String ns = scanner.next();

            if(first == null && incr(ns)){
                first = ns;
            }
        }

        if(first != null){
            System.out.println(first);
        }else System.out.println("не знаем таких");

    }

    private static boolean incr(String s){
        int pr = -1;
        boolean dig = false;

        for(int i = 0; i < s.length(); i++){
            char ch = s.charAt(i);
            if(Character.isDigit(ch)){
                int c = ch - '0';
                if(dig && c <= pr){
                    return false;
                }
                pr = c;
                dig = true;
            }

        }
        return dig;
    }
}
