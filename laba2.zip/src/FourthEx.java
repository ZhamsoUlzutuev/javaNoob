import java.util.Scanner;

public class FourthEx {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        String[] ns = new String[n];
        String bn = "";
        int minC = Integer.MAX_VALUE;
        System.out.println("Введите " + n + " чисел:");
        for(int i = 0; i < n; i++){
            String c = scanner.next();
            int d = coounter(c);

            if (d < minC){
                minC = d;
                bn = c;
            }
        }

        System.out.println("Число с минимальным количеством различных цифр: " + bn);
        System.out.println("Количество различных цифр в нём: " + minC);

    }

    private static int coounter(String s){
        String f = "";
        for(int i =0; i < s.length(); i++){
            char ch = s.charAt(i);
            if(Character.isDigit(ch) && f.indexOf(ch) == -1){
                f += ch;
            }
        }
        return f.length();
    }
}
