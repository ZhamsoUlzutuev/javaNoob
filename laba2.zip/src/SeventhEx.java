import java.util.Scanner;

public class SeventhEx {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        String first = null;
        System.out.println("Введите " + n + " чисел:");
        for(int i = 0; i < n; i++){
            String ns = scanner.next();

            if(first == null && allDiff(ns)){
                first = ns;
            }
        }

        if (first != null){
            System.out.println("Первое число с различными цифрами: " + first);
        }else System.out.println("Не знаем таких");
    }

    private static boolean allDiff(String s) {
        boolean[] seen = new boolean[10];

        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (Character.isDigit(ch)) {
                int digit = ch - '0';
                if (seen[digit]) {
                    return false;
                }
                seen[digit] = true;
            }
        }
        return true;
    }
}
