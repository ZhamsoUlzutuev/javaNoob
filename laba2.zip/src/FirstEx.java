import java.util.ArrayList;
import java.util.Scanner;

public class FirstEx {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите количество чисел: ");
        int n = scanner.nextInt();

        int min = Integer.MAX_VALUE;
        int max = 0;

        String minL = "";
        String maxL = "";

        System.out.println("Введите " + n + " чисел:");
        for(int i = 0; i < n; i++){
            String m = scanner.next();
            int len = m.length();

            if(len < min){
                min = len;
                minL = m;
            }

            if (len > max){
                max = len;
                maxL = m;
            }
        }

        System.out.println("Короткое число: " + minL + " длина: " + min );
        System.out.println("Длинное число: " + maxL + " длина: " + max );

        scanner.close();
    }
}





