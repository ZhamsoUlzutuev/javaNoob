import java.util.*;

public class Chapter11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Введите числа через пробел: ");
        String[] tokens = sc.nextLine().trim().split("\\s+");

        Set<Double> set = new HashSet<>();
        for (String t : tokens) {
            try {
                set.add(Double.parseDouble(t));
            }
            catch (NumberFormatException e) {
                System.out.println("Пропущено: " + t);
            }
        }

        List<Double> numbers = new ArrayList<>(set);
        System.out.println("Исходные данные: " + numbers);

        int stage = 1;
        while (numbers.size() > 1) {
            List<Double> next = new ArrayList<>();
            for (int i = 0; i < numbers.size(); i += 2) {
                if (i + 1 < numbers.size()) {
                    next.add(numbers.get(i) + numbers.get(i + 1));
                } else {
                    next.add(numbers.get(i));
                }
            }
            numbers = next;
            System.out.println("Этап " + stage + ": " + numbers);
            stage++;
        }
        System.out.println("Итог: " + numbers.get(0));
    }
}
