package lab7;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        String fileName = "D:\\javaIMP\\Gorod\\src\\lab7\\text.txt";
        List<String> targetWords = Arrays.asList("Java", "stream", "code", "python");

        try {
            String text = Files.readString(Path.of(fileName)).toLowerCase();

            String[] words = text.split("[^a-zа-яё0-9]+");

            Map<String, Long> frequencyMap = Arrays.stream(words).filter(w -> !w.isEmpty()).collect(Collectors.groupingBy(
                            w -> w,
                            Collectors.counting()
                    ));

            String result = targetWords.stream().map(w -> w + "-" + frequencyMap.getOrDefault(w.toLowerCase(), 0L))
                    .collect(Collectors.joining(", ", "[", "]"));

            System.out.println(result);

        } catch (IOException e) {
            System.err.println("Ошибка чтения файла: " + e.getMessage());
        }
    }
}
