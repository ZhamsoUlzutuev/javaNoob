public class Tablet extends BaseDrug{
    private int pills = 30;
    public Tablet(String name){
        super(name);
    }
    @Override
    public double calcDosage(double w){
        return Math.ceil((w * 10) / 50.0);
    }
    public int getPills(){
        return pills;
    }
}
