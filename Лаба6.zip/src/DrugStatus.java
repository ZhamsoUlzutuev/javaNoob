public enum DrugStatus {
    BANNED, PRESCRIPTION, ALLOWED
}
