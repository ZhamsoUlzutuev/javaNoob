public class Solution extends BaseDrug{
    private double ml = 100.0, percent = 5.0;
    public Solution(String name){
        super(name);
    }
    public void dilute(double addMl) {
        percent = (percent * ml) / (ml + addMl);
        ml += addMl;
        System.out.println(" Раствор разбавлен: " + ml + " мл, " + percent + "%");
    }
    public double getPercent(){
        return percent;
    }
}
