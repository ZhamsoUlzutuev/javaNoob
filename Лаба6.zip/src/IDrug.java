import java.util.Map;

public interface IDrug {
    void addSubstance(String name);
    double calcDosage(double weightKg);
    String research();
    void setStatus(DrugStatus status);
    Map<String, String> getInfo();
    void updateInfo(String key, String value);
}