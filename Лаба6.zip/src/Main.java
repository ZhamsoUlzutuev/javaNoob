public class Main {
    public static void main(String[] args) {
        Tablet tablet = new Tablet("Имянин");
        tablet.addSubstance("Какая-то субстанция");
        tablet.setStatus(DrugStatus.ALLOWED);
        tablet.updateInfo("Срок", "22.2026");
        System.out.println("Доза: " + tablet.calcDosage(61) + " таблеток");
        System.out.println(tablet.research() + "\n\n");

        Ointment o = new Ointment("Мазьракс");
        o.addSubstance("субстанция1");
        o.apply();
        System.out.println("Объем: " + o.getMl() + " мл\n\n");

        Solution s = new Solution("РАстворикс");
        s.addSubstance("натрийхлор");
        s.dilute(50);
        System.out.println("\n\n");

        Medicine m = new Medicine("Лекарствоцикс");
        m.setPrice(250);
        m.checkStock();
        System.out.println("Цена: " + m.getPrice() + " руб.");
    }

}