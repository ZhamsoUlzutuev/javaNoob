import java.util.HashMap;
import java.util.Map;

public abstract class BaseDrug implements IDrug {
    protected String name, substance;
    protected DrugStatus status = DrugStatus.BANNED;
    protected Map<String, String> info = new HashMap<>();

    public BaseDrug(String name) {
        this.name = name;
        info.put("Производитель", "Н/д");
        info.put("Срок годности", "Н/д");
    }

    public void addSubstance(String name) { this.substance = name; }
    public double calcDosage(double w) { return w * 10; } // мг
    public String research() {
        if(substance == null){
            return "Вещество не добавлено";
        }else{
            return "Исследование '" + substance + "' завершено.";
        }
    }
    public void setStatus(DrugStatus s){
        this.status = s;
    }
    public Map<String, String> getInfo() {
        return info;
    }
    public void updateInfo(String k, String v){
        info.put(k, v);
    }
}