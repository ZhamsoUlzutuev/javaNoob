public class Medicine extends BaseDrug{
    private double price = 100.0;
    public Medicine(String name){
        super(name);
    }
    public void checkStock(){
        System.out.println(" Склад: в наличии 150 уп.");
    }
    public double getPrice(){
        return price;
    }
    public void setPrice(double p){
        price = p;
    }
}
