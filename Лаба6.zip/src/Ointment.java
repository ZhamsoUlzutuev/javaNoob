public class Ointment extends BaseDrug{
    private double ml = 15.0;
    public Ointment(String name){
        super(name);
    }
    public void apply(){
        System.out.println(" Мазь нанесена на кожу.");
    }
    public double getMl(){
        return ml;
    }
}
