import java.util.Scanner;

public class Chapter8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите исходный текст: ");
        String text = scanner.nextLine();

        System.out.print("Введите начальный символ: ");
        String startInput = scanner.nextLine();
        char startChar = startInput.charAt(0);
        System.out.print("Введите конечный символ: ");
        String endInput = scanner.nextLine();
        char endChar = endInput.charAt(0);

        String result = removeBet(text, startChar, endChar);
        System.out.println("Результат:");
        System.out.println(result);

    }

    public static String removeBet(String text, char open, char close) {
        StringBuilder result = new StringBuilder();
        int currentIndex = 0;

        while (currentIndex < text.length()) {
            int openIndex = text.indexOf(open, currentIndex);

            if (openIndex == -1) {
                result.append(text.substring(currentIndex));
                break;
            }
            result.append(text, currentIndex, openIndex);


            int closeIndex = text.indexOf(close, openIndex + 1);
            if (closeIndex == -1) {
                result.append(open);
                currentIndex = openIndex + 1;
            } else {
                currentIndex = closeIndex + 1;
            }
        }
        return result.toString();
    }
}
